// Re-export the hook from the context for backwards compatibility
export { useFavorites } from '@/contexts/FavoritesContext';
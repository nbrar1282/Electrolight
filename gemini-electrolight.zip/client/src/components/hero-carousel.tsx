import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import type { HeroImage } from "@shared/schema";

// Fallback images in case no hero images are uploaded
const defaultHeroImages = [
  {
    url: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800",
    alt: "Professional electrical equipment display"
  },
  {
    url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800",
    alt: "Modern electronics and components"
  },
  {
    url: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800",
    alt: "Electrical components and wiring"
  }
];

export default function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  // Fetch hero images from the database
  const { data: dbHeroImages = [], isLoading } = useQuery<HeroImage[]>({
    queryKey: ['/api/hero-images'],
  });

  // Use uploaded images if available, otherwise fallback to default images
  // But wait for loading to complete to prevent image switching
  const heroImages = !isLoading && dbHeroImages.length > 0 
    ? dbHeroImages
        .filter(img => img.isActive)
        .sort((a, b) => a.order - b.order)
        .map(img => ({
          url: img.imageUrl,
          alt: img.title
        }))
    : defaultHeroImages;

  useEffect(() => {
    if (heroImages.length > 0) {
      // Reset to first slide when images change
      setCurrentSlide(0);
      
      const timer = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % heroImages.length);
      }, 4000);

      return () => clearInterval(timer);
    }
  }, [heroImages.length]);

  const scrollToProducts = () => {
    const element = document.getElementById('products');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative bg-gradient-to-r from-gray-900 to-gray-700 text-white">
      <div className="absolute inset-0 bg-black opacity-50"></div>
      
      {/* Carousel Images */}
      <div className="relative h-96 md:h-[500px] overflow-hidden">
        {heroImages.map((image, index) => (
          <div
            key={`${image.url}-${index}`}
            className={`carousel-slide absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
            style={{
              backgroundImage: `url(${image.url})`,
              backgroundSize: '100% 100%',
              backgroundPosition: 'center',
              // Prevent layout shifts during transitions
              minHeight: '100%',
              height: '100%'
            }}
          >
            <div className="absolute inset-0 bg-black bg-opacity-50"></div>
          </div>
        ))}
      </div>
      
      {/* Content Overlay */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center px-4">
          <div className="flex flex-col items-center justify-center mb-6">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
              ElectroLight
            </h1>
            <div className="w-24 h-1 bg-orange-500"></div>
          </div>
          <h2 className="text-2xl md:text-4xl font-bold mb-4">
            Professional Electrical Solutions
          </h2>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl">
            Quality electrical products and components for every project. From residential to commercial applications.
          </p>
          <Button 
            size="lg"
            className="bg-primary hover:bg-primary-dark text-white px-8 py-3 text-lg font-semibold"
            onClick={scrollToProducts}
          >
            Browse Products
          </Button>
        </div>
      </div>
    </section>
  );
}
